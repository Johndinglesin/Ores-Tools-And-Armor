/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.steelandrubyore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.steelandrubyore.OresToolsAndArmorMod;

public class OresToolsAndArmorModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, OresToolsAndArmorMod.MODID);
	public static final RegistryObject<SoundEvent> THESKINSTEALER = REGISTRY.register("theskinstealer", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("ores_tools_and_armor", "theskinstealer")));
}