/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.steelandrubyore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.steelandrubyore.block.*;
import net.mcreator.steelandrubyore.OresToolsAndArmorMod;

public class OresToolsAndArmorModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, OresToolsAndArmorMod.MODID);
	public static final RegistryObject<Block> STEEL_ORE;
	public static final RegistryObject<Block> RUBY_ORE;
	public static final RegistryObject<Block> BRONZE_ORE;
	public static final RegistryObject<Block> BRONZE_BLOCK_FULL;
	public static final RegistryObject<Block> STEEL_BLOCK;
	public static final RegistryObject<Block> RUBY_BLOCK;
	static {
		STEEL_ORE = REGISTRY.register("steel_ore", SteelOreBlock::new);
		RUBY_ORE = REGISTRY.register("ruby_ore", RubyOreBlock::new);
		BRONZE_ORE = REGISTRY.register("bronze_ore", BronzeBlockBlock::new);
		BRONZE_BLOCK_FULL = REGISTRY.register("bronze_block_full", BronzeBlockFullBlock::new);
		STEEL_BLOCK = REGISTRY.register("steel_block", SteelBlockBlock::new);
		RUBY_BLOCK = REGISTRY.register("ruby_block", RubyBlockBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}