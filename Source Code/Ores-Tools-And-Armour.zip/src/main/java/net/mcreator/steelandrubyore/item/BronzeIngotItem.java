package net.mcreator.steelandrubyore.item;

import net.minecraft.world.item.Item;

public class BronzeIngotItem extends Item {
	public BronzeIngotItem() {
		super(new Item.Properties());
	}
}