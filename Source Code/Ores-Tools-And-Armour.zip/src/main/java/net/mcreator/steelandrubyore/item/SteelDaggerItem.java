package net.mcreator.steelandrubyore.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.steelandrubyore.init.OresToolsAndArmorModItems;

public class SteelDaggerItem extends SwordItem {
	public SteelDaggerItem() {
		super(new Tier() {
			public int getUses() {
				return 123;
			}

			public float getSpeed() {
				return 4f;
			}

			public float getAttackDamageBonus() {
				return 5f;
			}

			public int getLevel() {
				return 0;
			}

			public int getEnchantmentValue() {
				return 2;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(OresToolsAndArmorModItems.STEEL_INGOT.get()));
			}
		}, 3, -3f, new Item.Properties());
	}
}