package net.mcreator.steelandrubyore.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class SteelOreBlock extends Block {
	public SteelOreBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.GRAVEL).strength(5f, 10f).requiresCorrectToolForDrops());
	}
}