/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.steelandrubyore.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.steelandrubyore.OresToolsAndArmorMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class OresToolsAndArmorModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OresToolsAndArmorMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(OresToolsAndArmorModBlocks.STEEL_ORE.get().asItem());
			tabData.accept(OresToolsAndArmorModItems.STEEL_INGOT.get());
			tabData.accept(OresToolsAndArmorModItems.BRONZE_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(OresToolsAndArmorModItems.STEEL_DAGGER.get());
			tabData.accept(OresToolsAndArmorModItems.STEEL_SWORD.get());
			tabData.accept(OresToolsAndArmorModItems.STEEL_PICKAXE.get());
			tabData.accept(OresToolsAndArmorModItems.STEELAXE.get());
			tabData.accept(OresToolsAndArmorModBlocks.RUBY_ORE.get().asItem());
			tabData.accept(OresToolsAndArmorModItems.RUBY_INGOT.get());
			tabData.accept(OresToolsAndArmorModItems.RUBY_SWORD.get());
			tabData.accept(OresToolsAndArmorModItems.RUBY_PICKAXE.get());
			tabData.accept(OresToolsAndArmorModItems.RUBY_AXE.get());
			tabData.accept(OresToolsAndArmorModBlocks.BRONZE_ORE.get().asItem());
			tabData.accept(OresToolsAndArmorModItems.BRONZE_SOWRD.get());
			tabData.accept(OresToolsAndArmorModItems.BRONZE_PCIKAXE.get());
			tabData.accept(OresToolsAndArmorModItems.BRONZE_AXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(OresToolsAndArmorModBlocks.BRONZE_BLOCK_FULL.get().asItem());
			tabData.accept(OresToolsAndArmorModBlocks.STEEL_BLOCK.get().asItem());
			tabData.accept(OresToolsAndArmorModBlocks.RUBY_BLOCK.get().asItem());
		}
	}
}