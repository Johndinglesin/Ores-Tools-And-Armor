package net.mcreator.steelandrubyore.item;

import net.minecraft.world.item.Item;

public class SteelIngotItem extends Item {
	public SteelIngotItem() {
		super(new Item.Properties());
	}
}