package net.mcreator.steelandrubyore.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class RubyOreBlock extends Block {
	public RubyOreBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.GRAVEL).strength(20f, 30f).requiresCorrectToolForDrops());
	}
}