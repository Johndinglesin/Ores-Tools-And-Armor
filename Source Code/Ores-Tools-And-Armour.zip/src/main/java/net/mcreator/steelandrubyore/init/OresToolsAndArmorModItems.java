/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.steelandrubyore.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.steelandrubyore.item.*;
import net.mcreator.steelandrubyore.OresToolsAndArmorMod;

public class OresToolsAndArmorModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, OresToolsAndArmorMod.MODID);
	public static final RegistryObject<Item> STEEL_ORE;
	public static final RegistryObject<Item> STEEL_INGOT;
	public static final RegistryObject<Item> STEEL_DAGGER;
	public static final RegistryObject<Item> STEEL_SWORD;
	public static final RegistryObject<Item> STEEL_PICKAXE;
	public static final RegistryObject<Item> STEELAXE;
	public static final RegistryObject<Item> RUBY_ORE;
	public static final RegistryObject<Item> RUBY_INGOT;
	public static final RegistryObject<Item> RUBY_SWORD;
	public static final RegistryObject<Item> RUBY_PICKAXE;
	public static final RegistryObject<Item> RUBY_AXE;
	public static final RegistryObject<Item> BRONZE_ORE;
	public static final RegistryObject<Item> BRONZE_INGOT;
	public static final RegistryObject<Item> BRONZE_SOWRD;
	public static final RegistryObject<Item> BRONZE_PCIKAXE;
	public static final RegistryObject<Item> BRONZE_AXE;
	public static final RegistryObject<Item> BRONZE_BLOCK_FULL;
	public static final RegistryObject<Item> STEEL_BLOCK;
	public static final RegistryObject<Item> RUBY_BLOCK;
	static {
		STEEL_ORE = block(OresToolsAndArmorModBlocks.STEEL_ORE);
		STEEL_INGOT = REGISTRY.register("steel_ingot", SteelIngotItem::new);
		STEEL_DAGGER = REGISTRY.register("steel_dagger", SteelDaggerItem::new);
		STEEL_SWORD = REGISTRY.register("steel_sword", SteelSwordItem::new);
		STEEL_PICKAXE = REGISTRY.register("steel_pickaxe", SteelPickaxeItem::new);
		STEELAXE = REGISTRY.register("steelaxe", SteelaxeItem::new);
		RUBY_ORE = block(OresToolsAndArmorModBlocks.RUBY_ORE);
		RUBY_INGOT = REGISTRY.register("ruby_ingot", RubyIngotItem::new);
		RUBY_SWORD = REGISTRY.register("ruby_sword", RubySwordItem::new);
		RUBY_PICKAXE = REGISTRY.register("ruby_pickaxe", RubyPickaxeItem::new);
		RUBY_AXE = REGISTRY.register("ruby_axe", RubyAxeItem::new);
		BRONZE_ORE = block(OresToolsAndArmorModBlocks.BRONZE_ORE);
		BRONZE_INGOT = REGISTRY.register("bronze_ingot", BronzeIngotItem::new);
		BRONZE_SOWRD = REGISTRY.register("bronze_sowrd", BronzeSowrdItem::new);
		BRONZE_PCIKAXE = REGISTRY.register("bronze_pcikaxe", BronzePcikaxeItem::new);
		BRONZE_AXE = REGISTRY.register("bronze_axe", BronzeAxeItem::new);
		BRONZE_BLOCK_FULL = block(OresToolsAndArmorModBlocks.BRONZE_BLOCK_FULL);
		STEEL_BLOCK = block(OresToolsAndArmorModBlocks.STEEL_BLOCK);
		RUBY_BLOCK = block(OresToolsAndArmorModBlocks.RUBY_BLOCK);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}