package net.mcreator.steelandrubyore.item;

import net.minecraft.world.item.Item;

public class RubyIngotItem extends Item {
	public RubyIngotItem() {
		super(new Item.Properties());
	}
}